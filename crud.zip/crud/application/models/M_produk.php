<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_produk extends CI_Model {

  public function get_data($where = 0) {
    if ($where == 0) {
      return $this->db->get('produk');
    } else {
      return $this->db->get_where('produk', $where);
    }
  }

  public function add_data($nama, $jumlah, $harga) {
    $produk = array(
      'nama'    => $nama,
      'jumlah'  => $jumlah,
      'harga'   => $harga
     );

     $this->db->insert('produk', $produk);
  }

  public function delete_data($where) {
    $this->db->where($where);
    $this->db->delete('produk');
  }

  public function edit_data($where, $produk) {
    $this->db->where($where);
    $this->db->update('produk', $produk);
  }
}
?>
