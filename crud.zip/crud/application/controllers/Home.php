<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller{

  public function __construct() {
    parent::__construct();
    $this->load->model('m_produk');
  }

  public function index() {
    $data['produk'] = $this->m_produk->get_data();

    $this->load->view('v_index', $data);
  }

  public function tambah_produk() {
    $this->form_validation->set_rules('nama', 'Nama', 'required');
    $this->form_validation->set_rules('jumlah', 'Jumlah', 'required');
    $this->form_validation->set_rules('harga', 'Harga', 'required');

    if ($this->form_validation->run()) {
      $nama   = $this->input->post('nama');
      $jumlah = $this->input->post('jumlah');
      $harga  = $this->input->post('harga');

      $this->m_produk->add_data($nama, $jumlah, $harga);

      $this->session->set_flashdata('pesan', '<span style="color: green;">Data berhasil ditambahkan</span>');

      redirect(base_url('home'));
    } else {
      $this->load->view('v_add');
    }
  }

  public function hapus_produk() {
    $where['id'] = $this->uri->segment(3);

    $this->m_produk->delete_data($where);

    $this->session->set_flashdata('pesan', 'Data berhasil dihapus');

    redirect(base_url('home'));
  }

  public function edit_produk() {
    $where['id']    = $this->uri->segment(3);

    $data['produk'] = $this->m_produk->get_data($where)->row_array();


    $this->form_validation->set_rules('nama', 'Nama', 'required');
    $this->form_validation->set_rules('jumlah', 'Jumlah', 'required');
    $this->form_validation->set_rules('harga', 'Harga', 'required');

    if ($this->form_validation->run()) {
      $id     = $this->input->post('id');
      $nama   = $this->input->post('nama');
      $jumlah = $this->input->post('jumlah');
      $harga  = $this->input->post('harga');

      $where['id'] = $id;

      $produk = array(
                'nama'    => $nama,
                'jumlah'  => $jumlah,
                'harga'   => $harga
      );

      $this->m_produk->edit_data($where, $produk);

      $this->session->set_flashdata('pesan', 'Data berhasil diubah');

      redirect(base_url('home'));
    } else {
      $this->load->view('v_edit', $data);
    }
  }
}
?>
