<?php echo form_open() ?>
<div>
  <label>Nama</label>
  <input type="hidden" name="id" value="<?php echo $produk['id']; ?>">
  <input type="text" name="nama" value="<?php echo $produk['nama']; ?>">
  <?php echo form_error('nama'); ?>
</div>
<div>
  <label>Jumlah</label>
  <input type="number" name="jumlah" value="<?php echo $produk['jumlah']; ?>">
  <?php echo form_error('jumlah'); ?>
</div>
<div>
  <label>Jumlah</label>
  <input type="number" name="harga" value="<?php echo $produk['harga']; ?>">
  <?php echo form_error('harga'); ?>
</div>
<div>
  <button type="submit">Edit</button>
</div>
<?php echo form_close() ?>
