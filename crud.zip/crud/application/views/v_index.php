<?php echo $this->session->flashdata('pesan'); ?>
<table border="1px">
  <tr>
    <th>ID</th>
    <th>NAMA</th>
    <th>JUMLAH</th>
    <th>HARGA</th>
    <th colspan="2">AKSI</th>
  </tr>
  <?php foreach ($produk->result_array() as $barang): ?>
    <tr>
      <td><?php echo $barang['id']; ?></td>
      <td><?php echo $barang['nama']; ?></td>
      <td><?php echo $barang['jumlah']; ?></td>
      <td><?php echo $barang['harga']; ?></td>
      <td><?php echo anchor('home/edit_produk/'.$barang['id'], 'Edit'); ?></td>
      <td><?php echo anchor('home/hapus_produk/'.$barang['id'], 'Hapus'); ?></td>
    </tr>
  <?php endforeach; ?>
</table>
<?php echo anchor('home/tambah_produk', 'Tambah Produk'); ?>
