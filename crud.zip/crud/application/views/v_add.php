<?php echo form_open(); ?>
  <div>
    <label>Masukkan Nama</label>
    <input type="text" name="nama">
    <?php echo form_error('nama'); ?>
  </div>
  <div>
    <label>Masukkan Jumlah</label>
    <input type="number" name="jumlah">
    <?php echo form_error('jumlah'); ?>
  </div>
  <div>
    <label>Masukkan Harga</label>
    <input type="number" name="harga">
    <?php echo form_error('harga'); ?>
  </div>
  <div>
    <button type="submit">Tambah</button>
  </div>
<?php echo form_close(); ?>
